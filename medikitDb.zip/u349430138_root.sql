-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 22, 2018 at 01:47 AM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `u349430138_root`
--

-- --------------------------------------------------------

--
-- Table structure for table `medikit_diseases`
--

CREATE TABLE IF NOT EXISTS `medikit_diseases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `disease_name` text COLLATE utf8_unicode_ci NOT NULL,
  `medicines_used` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `medikit_diseases`
--

INSERT INTO `medikit_diseases` (`id`, `disease_name`, `medicines_used`) VALUES
(1, 'Fever', 'naproxen,indomethacin,ibuprofen,Aleve,acetaminophen'),
(2, 'Diarrhoea', 'Lomotil oral,Levbid oral,diphenoxylate-atropine oral');

-- --------------------------------------------------------

--
-- Table structure for table `medikit_medicine_details`
--

CREATE TABLE IF NOT EXISTS `medikit_medicine_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medicine_name` text COLLATE utf8_unicode_ci NOT NULL,
  `medicine_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `medicine_use` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `medikit_medicine_details`
--

INSERT INTO `medikit_medicine_details` (`id`, `medicine_name`, `medicine_desc`, `medicine_use`) VALUES
(1, 'naproxen', 'Naproxen is used to relieve pain from various conditions such as headaches, muscle aches, tendonitis, dental pain, and menstrual cramps. It also reduces pain, swelling, and joint stiffness caused by arthritis, bursitis, and gout attacks. This medication is known as a nonsteroidal anti-inflammatory drug (NSAID). It works by blocking your body''s production of certain natural substances that cause inflammation.', 'Take this medication by mouth as directed by your doctor, usually 2 or 3 times a day with a full glass of water (8 ounces/240 milliliters). Do not lie down for at least 10 minutes after taking this drug. To prevent stomach upset, take this medication with food, milk, or an antacid.'),
(2, 'indomethacin', 'Indomethacin is used to relieve pain, swelling, and joint stiffness caused by arthritis, gout, bursitis, and tendonitis. It is also used to relieve pain from various other conditions. This medication is known as a nonsteroidal anti-inflammatory drug (NSAID). It works by blocking your body''s production of certain natural substances that cause inflammation. This effect helps to decrease swelling and pain.', 'Take this medication by mouth as directed by your doctor, usually 2 to 3 times a day with a full glass of water (8 ounces or 240 milliliters). Do not lie down for at least 10 minutes after taking this drug. If stomach upset occurs while taking this medication, take it with food, milk, or an antacid.'),
(3, 'ibuprofen', 'Ibuprofen is used to relieve pain from various conditions such as headache, dental pain, menstrual cramps, muscle aches, or arthritis. It is also used to reduce fever and to relieve minor aches and pain due to the common cold or flu. Ibuprofen is a nonsteroidal anti-inflammatory drug (NSAID). It works by blocking your body''s production of certain natural substances that cause inflammation. This effect helps to decrease swelling, pain, or fever.', 'Take this medication by mouth, usually every 4 to 6 hours with a full glass of water (8 ounces/240 milliliters) unless your doctor directs you otherwise. Do not lie down for at least 10 minutes after taking this drug. If you have stomach upset while taking this medication, take it with food, milk, or an antacid.'),
(4, 'Aleve', 'Naproxen is used to relieve pain from various conditions such as headache, muscle aches, dental pain, menstrual cramps, or arthritis. It is also used to reduce fever and relieve minor aches and pain due to the common cold or flu. This medication is known as a nonsteroidal anti-inflammatory drug (NSAID). It works by blocking your body''s production of certain natural substances that cause inflammation. This effect helps to decrease swelling, pain, or fever.', 'Take this medication by mouth as directed by your doctor or the package label, usually every 8 to 12 hours with a full glass of water (8 ounces/240 milliliters). Do not lie down for at least 10 minutes after taking this drug. To prevent stomach upset, take this medication with food, milk, or an antacid.'),
(5, 'acetaminophen', 'This drug is used to treat mild to moderate pain (from headaches, menstrual periods, toothaches, backaches, osteoarthritis, or cold/flu aches and pains) and to reduce fever.', 'For suspensions, shake the medication well before each dose. Some liquids do not need to be shaken before use. Follow all directions on the product package. Measure the liquid medication with the provided dose-measuring spoon/dropper/syringe to make sure you have the correct dose. Do not use a household spoon.');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
